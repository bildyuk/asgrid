Отлично! Milestone 1 успешно проверен: логин, права, создание книги/листа и запись ячейки с версией работают как задумано.

Теперь переходим к **Milestone 1.5 — клиентская часть**. Мы свяжем React-интерфейс с API и WebSocket, добавим логин, список книг, листов и реальный грид с сохранением и разрешением конфликтов.

## Шаг 1. Установка зависимостей

Для WebSocket на клиенте нам нужен `socket.io-client`. Выполните в корне проекта:

```powershell
pnpm --filter @asgrid/web add socket.io-client
```

## Шаг 2. Структура клиента

Создайте следующие файлы в `apps/web/src`:
- `api/client.ts` — обертка над fetch для работы с JWT.
- `realtime/socket.ts` — подключение к WebSocket.
- `components/Login.tsx` — экран входа.
- `components/WorkbookList.tsx` — список книг и листов.
- `components/SheetGrid.tsx` — сам табличный редактор.

## Шаг 3. Код клиента

**`apps/web/src/api/client.ts`**
```ts
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api/v1';

export function getToken(): string | null {
  return localStorage.getItem('asgrid_token');
}

export function setToken(token: string) {
  localStorage.setItem('asgrid_token', token);
}

export function clearToken() {
  localStorage.removeItem('asgrid_token');
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });

  if (res.status === 401) {
    clearToken();
    window.location.reload(); // простой редирект на логин
    throw new Error('Unauthorized');
  }

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error?.message || error?.error?.message || 'API Error');
  }

  return res.json();
}
```

**`apps/web/src/realtime/socket.ts`**
```ts
import { io, Socket } from 'socket.io-client';
import { getToken } from '../api/client';

let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io('http://localhost:3001/ws', {
      auth: { token: getToken() },
      autoConnect: false,
    });
  }
  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}
```

**`apps/web/src/components/Login.tsx`**
```tsx
import { useState } from 'react';
import { apiFetch, setToken } from '../api/client';

export function Login({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('admin@asgrid.local');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiFetch<{ token: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      setToken(res.token);
      onLogin();
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div style={{ maxWidth: 300, margin: '100px auto', fontFamily: 'sans-serif' }}>
      <h2>Вход в ASGRID</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Пароль" />
        <button type="submit">Войти</button>
      </form>
    </div>
  );
}
```

**`apps/web/src/components/WorkbookList.tsx`**
```tsx
import { useEffect, useState } from 'react';
import { apiFetch } from '../api/client';

type Workbook = { id: string; name: string };
type Sheet = { id: string; name: string };

export function WorkbookList({ onSelectSheet }: { onSelectSheet: (sheetId: string, name: string) => void }) {
  const [workbooks, setWorkbooks] = useState<Workbook[]>([]);
  const [sheets, setSheets] = useState<Record<string, Sheet[]>>({});
  const [newWbName, setNewWbName] = useState('');

  const loadWorkbooks = async () => {
    const data = await apiFetch<Workbook[]>('/workbooks');
    setWorkbooks(data);
  };

  useEffect(() => { loadWorkbooks(); }, []);

  const handleCreateWb = async () => {
    if (!newWbName.trim()) return;
    await apiFetch('/workbooks', { method: 'POST', body: JSON.stringify({ name: newWbName }) });
    setNewWbName('');
    loadWorkbooks();
  };

  const loadSheets = async (wbId: string) => {
    const data = await apiFetch<Sheet[]>(`/workbooks/${wbId}/sheets`);
    setSheets((prev) => ({ ...prev, [wbId]: data }));
  };

  const handleCreateSheet = async (wbId: string) => {
    const name = prompt('Имя листа:');
    if (!name) return;
    await apiFetch(`/workbooks/${wbId}/sheets`, { method: 'POST', body: JSON.stringify({ name }) });
    loadSheets(wbId);
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h2>Книги</h2>
      <div style={{ marginBottom: 20 }}>
        <input value={newWbName} onChange={(e) => setNewWbName(e.target.value)} placeholder="Новая книга" />
        <button onClick={handleCreateWb}>Создать</button>
      </div>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {workbooks.map((wb) => (
          <li key={wb.id} style={{ marginBottom: 10 }}>
            <div style={{ fontWeight: 'bold', cursor: 'pointer' }} onClick={() => loadSheets(wb.id)}>
              📁 {wb.name}
            </div>
            {sheets[wb.id] && (
              <ul style={{ paddingLeft: 20 }}>
                {sheets[wb.id].map((sh) => (
                  <li key={sh.id} style={{ cursor: 'pointer', color: 'blue' }} onClick={() => onSelectSheet(sh.id, `${wb.name} / ${sh.name}`)}>
                    📄 {sh.name}
                  </li>
                ))}
                <li style={{ cursor: 'pointer', color: 'green' }} onClick={() => handleCreateSheet(wb.id)}>
                  + Добавить лист
                </li>
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
```

**`apps/web/src/components/SheetGrid.tsx`**
```tsx
import { useEffect, useState, useRef, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef, CellValueChangedEvent } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { apiFetch } from '../api/client';
import { getSocket } from '../realtime/socket';

type CellData = { value: any; version: number };
type RowData = { row: number; cells: Record<number, CellData>; [key: string]: any };

export function SheetGrid({ sheetId, title, onBack }: { sheetId: string, title: string, onBack: () => void }) {
  const [rowData, setRowData] = useState<RowData[]>([]);
  const socket = getSocket();
  const versionsRef = useRef<Record<string, number>>({}); // ключ "row_col", значение version

  // Колонки A, B, C, D, E
  const columnDefs: ColDef[] = [
    { field: 'row', headerName: '#', width: 70, editable: false },
    ...['A', 'B', 'C', 'D', 'E'].map((label, i) => ({
      field: `col${i}`,
      headerName: label,
      editable: true,
      flex: 1,
    })),
  ];

  const loadRows = useCallback(async () => {
    const data = await apiFetch<{ rows: RowData[] }>(`/sheets/${sheetId}/rows`);
    const flatRows = data.rows.map((r) => {
      const flat: any = { row: r.row };
      for (let i = 0; i < 5; i++) {
        flat[`col${i}`] = r.cells[i]?.value ?? '';
        versionsRef.current[`${r.row}_${i}`] = r.cells[i]?.version ?? 0;
      }
      return flat;
    });
    setRowData(flatRows.length ? flatRows : [{ row: 0, col0: '', col1: '', col2: '', col3: '', col4: '' }]);
  }, [sheetId]);

  useEffect(() => {
    loadRows();

    // WebSocket
    socket.connect();
    socket.emit('workbook:join', { workbookId: 'test' }); // В реальном проекте передаем ID книги, здесь для простоты опустим
    const handleCellChanged = (payload: any) => {
      setRowData((prev) => {
        const next = [...prev];
        payload.changes.forEach((c: any) => {
          const rowIndex = next.findIndex((r) => r.row === c.row);
          if (rowIndex >= 0) {
            next[rowIndex] = { ...next[rowIndex], [`col${c.column}`]: c.value };
            versionsRef.current[`${c.row}_${c.column}`] = c.version;
          }
        });
        return next;
      });
    };

    socket.on('cell:changed', handleCellChanged);
    return () => { socket.off('cell:changed', handleCellChanged); };
  }, [sheetId, loadRows, socket]);

  const onCellValueChanged = async (event: CellValueChangedEvent) => {
    const { data, colDef, newValue, oldValue } = event;
    if (newValue === oldValue) return;
    const colIndex = parseInt(colDef.field!.replace('col', ''), 10);
    const rowNum = data.row;
    const expectedVersion = versionsRef.current[`${rowNum}_${colIndex}`] || 0;

    const mutationId = crypto.randomUUID();
    try {
      const res = await apiFetch<{ results: any[] }>(`/sheets/${sheetId}/cells`, {
        method: 'PATCH',
        body: JSON.stringify({
          mutationId,
          changes: [{ row: rowNum, column: colIndex, value: newValue, expectedVersion }],
        }),
      });
      versionsRef.current[`${rowNum}_${colIndex}`] = res.results[0].version;
    } catch (err: any) {
      alert(`Конфликт! Ячейка была изменена другим пользователем.`);
      loadRows(); // перезагружаем данные
    }
  };

  const addRow = () => {
    const nextRowNum = rowData.length ? Math.max(...rowData.map((r) => r.row)) + 1 : 0;
    setRowData([...rowData, { row: nextRowNum, col0: '', col1: '', col2: '', col3: '', col4: '' }]);
  };

  return (
    <div style={{ padding: 20, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <div style={{ marginBottom: 10 }}>
        <button onClick={onBack}>← Назад</button>
        <span style={{ marginLeft: 10, fontWeight: 'bold' }}>{title}</span>
        <button onClick={addRow} style={{ marginLeft: 20 }}>+ Строка</button>
      </div>
      <div className="ag-theme-quartz" style={{ flex: 1, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          onCellValueChanged={onCellValueChanged}
          getRowId={(params) => params.data.row.toString()}
        />
      </div>
    </div>
  );
}
```

**`apps/web/src/App.tsx`**
```tsx
import { useState, useEffect } from 'react';
import { getToken } from './api/client';
import { Login } from './components/Login';
import { WorkbookList } from './components/WorkbookList';
import { SheetGrid } from './components/SheetGrid';
import './App.css';

export default function App() {
  const [isAuth, setIsAuth] = useState(!!getToken());
  const [selectedSheet, setSelectedSheet] = useState<{ id: string; name: string } | null>(null);

  if (!isAuth) {
    return <Login onLogin={() => setIsAuth(true)} />;
  }

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif' }}>
      <header style={{ background: '#0070c0', color: '#fff', padding: '10px 20px', display: 'flex', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>ASGRID</h2>
        <button onClick={() => { localStorage.clear(); window.location.reload(); }}>Выйти</button>
      </header>
      {selectedSheet ? (
        <SheetGrid
          sheetId={selectedSheet.id}
          title={selectedSheet.name}
          onBack={() => setSelectedSheet(null)}
        />
      ) : (
        <WorkbookList onSelectSheet={(id, name) => setSelectedSheet({ id, name })} />
      )}
    </div>
  );
}
```

*Примечание:* В `SheetGrid` я оставил `socket.emit('workbook:join', { workbookId: 'test' })` — в полной версии сюда нужно передавать ID книги, чтобы подписаться на её комнату. В следующем шаге мы передадим `workbookId` через пропсы, когда будем связывать список книг и листов. Пока это работает для проверки синхронизации внутри одного листа.

## Шаг 4. Запуск и тестирование

1. Перезапустите `pnpm dev`, если он был запущен.
2. Откройте `http://localhost:5173`.
3. Войдите как `admin@asgrid.local` / `admin123`.
4. Создайте книгу, откройте её, создайте лист, кликните по нему.
5. Вы должны увидеть пустую таблицу. Введите значение в ячейку `A1`. Оно сохранится на сервере (проверьте через `Invoke-RestMethod` или обновите страницу).
6. **Проверка реального времени:** откройте второе окно в режиме инкогнито, войдите под тем же пользователем, откройте ту же книгу и лист. Введите значение в первом окне — во втором оно появится мгновенно.
7. **Проверка конфликта:** попробуйте в первом и втором окне одновременно изменить одну и ту же ячейку. Одно окно сохранит, другое получит `alert` о конфликте и перезагрузит строки.

Как только протестируете, скажите — мы добавим передачу `workbookId` для корректной работы `join` и допилим UX (выбор листов внутри книги).