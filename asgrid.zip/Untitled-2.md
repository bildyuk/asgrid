Продолжаю. Ниже — содержимое **Milestone 0**: каркас монорепозитория, инфраструктура, Prisma-схема, минимальные NestJS и React приложения, контракты API. ZIP не прикладываю — файлы ниже можно сохранить вручную или скриптом (предложу в конце).

## Структура

```
asgrid/
├── package.json
├── pnpm-workspace.yaml
├── docker-compose.yml
├── .env.example
├── .gitignore
├── apps/
│   ├── api/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── nest-cli.json
│   │   ├── prisma/schema.prisma
│   │   └── src/
│   │       ├── main.ts
│   │       ├── app.module.ts
│   │       ├── health/health.controller.ts
│   │       └── prisma/{prisma.module.ts,prisma.service.ts}
│   └── web/
│       ├── package.json
│       ├── tsconfig.json
│       ├── vite.config.ts
│       ├── index.html
│       └── src/{main.tsx,App.tsx}
└── docs/API.md
```

## 1. Корень

**`package.json`**
```json
{
  "name": "asgrid",
  "private": true,
  "packageManager": "pnpm@9.12.0",
  "scripts": {
    "dev": "pnpm -r --parallel dev",
    "dev:api": "pnpm --filter @asgrid/api dev",
    "dev:web": "pnpm --filter @asgrid/web dev",
    "build": "pnpm -r build",
    "db:migrate": "pnpm --filter @asgrid/api prisma migrate dev",
    "db:generate": "pnpm --filter @asgrid/api prisma generate",
    "db:studio": "pnpm --filter @asgrid/api prisma studio"
  }
}
```

**`pnpm-workspace.yaml`**
```yaml
packages:
  - "apps/*"
```

**`docker-compose.yml`**
```yaml
services:
  postgres:
    image: postgres:16
    restart: unless-stopped
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-asgrid}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-asgrid}
      POSTGRES_DB: ${POSTGRES_DB:-asgrid}
    ports:
      - "${POSTGRES_PORT:-5432}:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-asgrid}"]
      interval: 5s
      timeout: 5s
      retries: 10

volumes:
  pgdata:
```

**`.env.example`**
```
NODE_ENV=development
API_PORT=3001
DATABASE_URL=postgresql://asgrid:asgrid@localhost:5432/asgrid
JWT_SECRET=change-me-in-production
JWT_EXPIRES_IN=1d
WEB_ORIGIN=http://localhost:5173
VITE_API_URL=http://localhost:3001/api/v1
```

**`.gitignore`**
```
node_modules/
dist/
.env
.env.local
*.log
.DS_Store
apps/api/prisma/migrations/dev.db*
```

## 2. Prisma-схема

**`apps/api/prisma/schema.prisma`**
```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id           String   @id @default(uuid()) @db.Uuid
  email        String   @unique
  passwordHash String
  displayName  String
  role         String   @default("editor") // "admin" | "editor"
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  ownedWorkbooks Workbook[]       @relation("WorkbookOwner")
  memberships    WorkbookMember[]
  cellChanges    CellChange[]
}

model Workbook {
  id        String   @id @default(uuid()) @db.Uuid
  name      String
  ownerId   String   @db.Uuid
  owner     User     @relation("WorkbookOwner", fields: [ownerId], references: [id])
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  members WorkbookMember[]
  sheets  Sheet[]
  events  WorkbookEvent[]

  @@index([ownerId])
}

model WorkbookMember {
  workbookId String   @db.Uuid
  userId     String   @db.Uuid
  role       String   // "owner" | "editor"
  createdAt  DateTime @default(now())

  workbook Workbook @relation(fields: [workbookId], references: [id], onDelete: Cascade)
  user     User     @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@id([workbookId, userId])
  @@index([userId])
}

model Sheet {
  id         String   @id @default(uuid()) @db.Uuid
  workbookId String   @db.Uuid
  name       String
  position   Int      @default(0)
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt

  workbook Workbook     @relation(fields: [workbookId], references: [id], onDelete: Cascade)
  cells    Cell[]
  changes  CellChange[]

  @@unique([workbookId, name])
  @@index([workbookId])
}

model Cell {
  id        String   @id @default(uuid()) @db.Uuid
  sheetId   String   @db.Uuid
  row       Int
  column    Int
  value     Json?    // string | number | null
  version   Int      @default(0)
  updatedAt DateTime @updatedAt

  sheet Sheet @relation(fields: [sheetId], references: [id], onDelete: Cascade)

  @@unique([sheetId, row, column])
}

model CellChange {
  id         String   @id @default(uuid()) @db.Uuid
  mutationId String   @unique @db.Uuid
  sheetId    String   @db.Uuid
  cellId     String   @db.Uuid
  userId     String   @db.Uuid
  row        Int
  column     Int
  oldValue   Json?
  newValue   Json?
  version    Int
  createdAt  DateTime @default(now())

  sheet Sheet @relation(fields: [sheetId], references: [id], onDelete: Cascade)
  user  User  @relation(fields: [userId], references: [id])

  @@index([sheetId, createdAt])
}

model WorkbookEvent {
  seq        Int      @id @default(autoincrement())
  workbookId String   @db.Uuid
  type       String   // "cell:changed" | "sheet:created" | ...
  payload    Json
  createdAt  DateTime @default(now())

  workbook Workbook @relation(fields: [workbookId], references: [id], onDelete: Cascade)

  @@index([workbookId, seq])
}
```

Замечания:
- `workbook_events.seq` — глобальный `serial`; клиент запрашивает `?after=<seq>`, сервер фильтрует по `workbookId AND seq > after`. Для MVP `Int` достаточно, при росте переключим на `BigInt`.
- `cells.value` — `Json?`, чтобы вместить `string | number | null` без потери типа. Позже можно добавить `type`/`formula` отдельными полями.
- `cell_changes.mutationId` — `@unique`, идемпотентность повторной отправки.
- `cell_changes.cellId` без FK, чтобы история переживала удаление строк.

## 3. NestJS

**`apps/api/package.json`**
```json
{
  "name": "@asgrid/api",
  "version": "0.0.1",
  "private": true,
  "scripts": {
    "dev": "nest start --watch",
    "build": "nest build",
    "start": "node dist/main.js",
    "prisma": "prisma"
  },
  "dependencies": {
    "@nestjs/common": "^10.4.0",
    "@nestjs/core": "^10.4.0",
    "@nestjs/platform-express": "^10.4.0",
    "@prisma/client": "^5.20.0",
    "reflect-metadata": "^0.2.2",
    "rxjs": "^7.8.1"
  },
  "devDependencies": {
    "@nestjs/cli": "^10.4.5",
    "@types/node": "^20.16.0",
    "prisma": "^5.20.0",
    "ts-node": "^10.9.2",
    "typescript": "^5.5.4"
  }
}
```

**`apps/api/tsconfig.json`**
```json
{
  "compilerOptions": {
    "module": "commonjs",
    "target": "ES2022",
    "moduleResolution": "node",
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "strict": true,
    "outDir": "dist",
    "rootDir": "src",
    "sourceMap": true
  },
  "include": ["src/**/*.ts"]
}
```

**`apps/api/nest-cli.json`**
```json
{
  "$schema": "https://json.schemastore.org/nest-cli",
  "collection": "@nestjs/schematics",
  "sourceRoot": "src",
  "compilerOptions": { "deleteOutDir": true }
}
```

**`apps/api/src/main.ts`**
```ts
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.setGlobalPrefix('api/v1');
  app.enableCors({
    origin: process.env.WEB_ORIGIN ?? 'http://localhost:5173',
    credentials: true,
  });
  const port = Number(process.env.API_PORT ?? 3001);
  await app.listen(port);
  console.log(`API on http://localhost:${port}/api/v1`);
}
bootstrap();
```

**`apps/api/src/app.module.ts`**
```ts
import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { HealthController } from './health/health.controller';

@Module({
  imports: [PrismaModule],
  controllers: [HealthController],
})
export class AppModule {}
```

**`apps/api/src/prisma/prisma.module.ts`**
```ts
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService],
})
export class PrismaModule {}
```

**`apps/api/src/prisma/prisma.service.ts`**
```ts
import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient
  implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() { await this.$connect(); }
  async onModuleDestroy() { await this.$disconnect(); }
}
```

**`apps/api/src/health/health.controller.ts`**
```ts
import { Controller, Get } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Controller('health')
export class HealthController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  async check() {
    await this.prisma.$queryRaw`SELECT 1`;
    return { status: 'ok', time: new Date().toISOString() };
  }
}
```

## 4. React + AG Grid

**`apps/web/package.json`**
```json
{
  "name": "@asgrid/web",
  "version": "0.0.1",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview --port 5173",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "ag-grid-community": "^31.3.4",
    "ag-grid-react": "^31.3.4",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/react": "^18.3.5",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.1",
    "typescript": "^5.5.4",
    "vite": "^5.4.2"
  }
}
```

**`apps/web/tsconfig.json`**
```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "types": ["vite/client"],
    "noEmit": true
  },
  "include": ["src"]
}
```

**`apps/web/vite.config.ts`**
```ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 5173 },
});
```

**`apps/web/index.html`**
```html
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ASGRID</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

**`apps/web/src/main.tsx`**
```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
```

**`apps/web/src/App.tsx`**
```tsx
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

type Row = { id: number; name: string; amount: number };

const columnDefs: ColDef<Row>[] = [
  { field: 'id', headerName: '#', width: 80, editable: false },
  { field: 'name', headerName: 'Наименование', editable: true, flex: 1 },
  { field: 'amount', headerName: 'Сумма', editable: true, width: 140 },
];

export default function App() {
  const [rows] = useState<Row[]>([
    { id: 1, name: 'Пример строки', amount: 100 },
    { id: 2, name: 'Вторая строка', amount: 250 },
  ]);

  return (
    <div style={{ padding: 16, fontFamily: 'system-ui, sans-serif' }}>
      <h1 style={{ margin: '0 0 12px' }}>ASGRID</h1>
      <p style={{ color: '#666', margin: '0 0 12px' }}>
        Milestone 0 — каркас интерфейса. Данные пока локальные, без API.
      </p>
      <div className="ag-theme-quartz" style={{ height: 360 }}>
        <AgGridReact<Row> rowData={rows} columnDefs={columnDefs} />
      </div>
    </div>
  );
}
```

## 5. Контракты API

**`docs/API.md`**
```md
# ASGRID API — контракты v1

Базовый префикс: `/api/v1`. Формат: JSON.
Аутентификация: `Authorization: Bearer <jwt>`.

## Ошибки

| HTTP | code              | Значение |
|------|-------------------|----------|
| 400  | VALIDATION_ERROR  | невалидный запрос |
| 401  | UNAUTHORIZED      | нет/истёк токен |
| 403  | FORBIDDEN         | нет доступа |
| 404  | NOT_FOUND         | не найдено |
| 409  | VERSION_CONFLICT  | expectedVersion не совпал |
| 409  | DUPLICATE_MUTATION| mutationId уже применён |

Формат: `{ "error": { "code": "...", "message": "...", "details": {...} } }`

## Auth

- `POST /auth/login` — `{ email, password }` → `{ token, user }`
- `GET  /auth/me` → текущий пользователь

## Workbooks

- `GET  /workbooks` → доступные книги
- `POST /workbooks` — `{ name }` → книга (владелец = текущий)
- `GET  /workbooks/:id/sheets` → листы
- `POST /workbooks/:id/sheets` — `{ name }` → лист

## Sheets

- `GET /sheets/:id/rows?limit=&offset=` → строки листа в виде разрежённой карты ячеек
- `PATCH /sheets/:id/cells` — изменение ячеек (см. ниже)
- `GET /sheets/:id/events?after=<seq>` → пропущенные события для догона

### PATCH /sheets/:id/cells

Запрос:
```json
{
  "mutationId": "uuid",
  "changes": [
    { "row": 3, "column": 1, "value": 250, "expectedVersion": 7 }
  ]
}
```

Ответ 200:
```json
{
  "mutationId": "uuid",
  "seq": 128,
  "results": [
    { "row": 3, "column": 1, "value": 250, "version": 8 }
  ]
}
```

Ответ 409 (частичный конфликт — изменяем всё или ничего, отклоняем всю пачку):
```json
{
  "error": {
    "code": "VERSION_CONFLICT",
    "message": "cell version mismatch",
    "details": {
      "conflicts": [
        { "row": 3, "column": 1, "expectedVersion": 7, "currentVersion": 8, "currentValue": 260 }
      ]
    }
  }
}
```

Если тот же `mutationId` приходит повторно — сервер возвращает сохранённый результат (200), не применяя изменение второй раз.

## WebSocket

Namespace `/ws`. JWT в `auth.token` handshake.

Клиент → сервер:
- `workbook:join` `{ workbookId }`
- `cell:mutate` `{ workbookId, sheetId, mutationId, changes: [...] }`

Сервер → клиент:
- `cell:changed` `{ sheetId, seq, changes: [...] }`
- `cell:conflict` `{ sheetId, mutationId, conflicts: [...] }`
- `sync:required` `{ workbookId, lastSeq }` — клиент догоняет через `GET /sheets/:id/events?after=...`
```

## 6. Запуск Milestone 0

```bash
cp .env.example .env
pnpm install
docker compose up -d postgres
pnpm db:migrate           # prisma migrate dev --name init
pnpm dev                  # API :3001, web :5173
curl http://localhost:3001/api/v1/health
```

Критерий готовности: PostgreSQL поднят, миграция прошла, `/health` отвечает `{"status":"ok"}`, в браузере на `:5173` открывается грид.

## 7. Что дальше (Milestone 1)

1. `AuthModule`: `POST /auth/login`, JWT guard, `GET /auth/me`, скрипт создания первого администратора.
2. `WorkbooksModule` + `SheetsModule`: CRUD книг/листов с проверкой членства.
3. `CellsModule`: `GET /rows`, `PATCH /cells` в одной транзакции (`cells` + `cell_changes` + `workbook_events`), идемпотентность по `mutationId`.
4. `RealtimeModule`: шлюз на `@nestjs/websockets`, `workbook:join` c проверкой прав, `cell:mutate`, рассылка `cell:changed` по книге.
5. `GET /sheets/:id/events?after=seq` + `sync:required` на клиенте.

Хотите — следующим сообщением соберу **Milestone 1 целиком** (auth + books/sheets + cells + realtime) в том же формате. Или, если удобнее, дам одну bash-команду со `cat <<'EOF'` для всех файлов Milestone 0, чтобы развернуть репозиторий за один прогон — скажите, какой вариант.