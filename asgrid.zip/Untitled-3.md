Milestone 0 закрыт. Переходим к **Milestone 1**: авторизация, книги, листы, сохранение ячеек с версиями и идемпотентностью, WebSocket для реального времени.

## Порядок в этом сообщении

1. Обновляем зависимости и схему Prisma.
2. Auth (JWT, login, me, seed админа).
3. Workbooks + Sheets.
4. Cells (rows, patch с версиями, events).
5. Realtime (WS-шлюз).
6. Команды запуска и проверка.

---

## 1. Зависимости и схема

**`apps/api/package.json`** (полная замена)
```json
{
  "name": "@asgrid/api",
  "version": "0.0.1",
  "private": true,
  "scripts": {
    "dev": "nest start --watch",
    "build": "nest build",
    "start": "node dist/main.js",
    "prisma": "prisma"
  },
  "prisma": {
    "seed": "node prisma/seed.js"
  },
  "dependencies": {
    "@nestjs/common": "^10.4.0",
    "@nestjs/core": "^10.4.0",
    "@nestjs/jwt": "^10.2.0",
    "@nestjs/platform-express": "^10.4.0",
    "@nestjs/platform-socket.io": "^10.4.0",
    "@nestjs/websockets": "^10.4.0",
    "@prisma/client": "^5.20.0",
    "bcryptjs": "^2.4.3",
    "class-transformer": "^0.5.1",
    "class-validator": "^0.14.1",
    "reflect-metadata": "^0.2.2",
    "rxjs": "^7.8.1",
    "socket.io": "^4.7.5"
  },
  "devDependencies": {
    "@nestjs/cli": "^10.4.5",
    "@types/bcryptjs": "^2.4.6",
    "@types/node": "^20.16.0",
    "prisma": "^5.20.0",
    "ts-node": "^10.9.2",
    "typescript": "^5.5.4"
  }
}
```

**`apps/api/prisma/schema.prisma`** (полная замена)
```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id           String   @id @default(uuid()) @db.Uuid
  email        String   @unique
  passwordHash String
  displayName  String
  role         String   @default("editor")
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  ownedWorkbooks Workbook[]       @relation("WorkbookOwner")
  memberships    WorkbookMember[]
  cellChanges    CellChange[]
}

model Workbook {
  id        String   @id @default(uuid()) @db.Uuid
  name      String
  ownerId   String   @db.Uuid
  owner     User     @relation("WorkbookOwner", fields: [ownerId], references: [id])
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  members WorkbookMember[]
  sheets  Sheet[]
  events  WorkbookEvent[]

  @@index([ownerId])
}

model WorkbookMember {
  workbookId String   @db.Uuid
  userId     String   @db.Uuid
  role       String
  createdAt  DateTime @default(now())

  workbook Workbook @relation(fields: [workbookId], references: [id], onDelete: Cascade)
  user     User     @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@id([workbookId, userId])
  @@index([userId])
}

model Sheet {
  id         String   @id @default(uuid()) @db.Uuid
  workbookId String   @db.Uuid
  name       String
  position   Int      @default(0)
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt

  workbook Workbook     @relation(fields: [workbookId], references: [id], onDelete: Cascade)
  cells    Cell[]
  changes  CellChange[]

  @@unique([workbookId, name])
  @@index([workbookId])
}

model Cell {
  id        String   @id @default(uuid()) @db.Uuid
  sheetId   String   @db.Uuid
  row       Int
  column    Int
  value     Json?
  version   Int      @default(0)
  updatedAt DateTime @updatedAt

  sheet Sheet @relation(fields: [sheetId], references: [id], onDelete: Cascade)

  @@unique([sheetId, row, column])
}

model CellChange {
  id         String   @id @default(uuid()) @db.Uuid
  mutationId String   @db.Uuid
  sheetId    String   @db.Uuid
  cellId     String   @db.Uuid
  userId     String   @db.Uuid
  row        Int
  column     Int
  oldValue   Json?
  newValue   Json?
  version    Int
  seq        Int      @default(0)
  createdAt  DateTime @default(now())

  sheet Sheet @relation(fields: [sheetId], references: [id], onDelete: Cascade)
  user  User  @relation(fields: [userId], references: [id])

  @@index([mutationId])
  @@index([sheetId, createdAt])
}

model WorkbookEvent {
  seq        Int      @id @default(autoincrement())
  workbookId String   @db.Uuid
  sheetId    String?  @db.Uuid
  type       String
  payload    Json
  createdAt  DateTime @default(now())

  workbook Workbook @relation(fields: [workbookId], references: [id], onDelete: Cascade)

  @@index([workbookId, seq])
  @@index([sheetId, seq])
}
```

Ключевые изменения:
- `cell_changes.mutationId` — больше не `@unique`, чтобы одна мутация могла содержать много ячеек; уникальность обеспечивается проверкой на существование в коде.
- `cell_changes.seq` — ссылка на событие `workbook_events`, чтобы при повторе `mutationId` вернуть тот же ответ.
- `workbook_events.sheetId` — для фильтра по листу.

**`apps/api/prisma/seed.js`** (создать администратора)
```js
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL || 'admin@asgrid.local';
  const password = process.env.ADMIN_PASSWORD || 'admin123';
  const displayName = process.env.ADMIN_NAME || 'Administrator';

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`User ${email} already exists, skipping`);
    return;
  }
  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.create({
    data: { email, passwordHash, displayName, role: 'admin' },
  });
  console.log(`Created admin: ${email} / ${password}`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
```

## 2. Общие части

**`apps/api/src/main.ts`** (замена — добавлен `ValidationPipe`)
```ts
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.setGlobalPrefix('api/v1');
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  app.enableCors({
    origin: process.env.WEB_ORIGIN ?? 'http://localhost:5173',
    credentials: true,
  });
  const port = Number(process.env.API_PORT ?? 3001);
  await app.listen(port);
  console.log(`API on http://localhost:${port}/api/v1`);
}
bootstrap();
```

**`apps/api/src/app.module.ts`** (замена)
```ts
import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { EventsModule } from './events/events.module';
import { AuthModule } from './auth/auth.module';
import { WorkbooksModule } from './workbooks/workbooks.module';
import { SheetsModule } from './sheets/sheets.module';
import { RealtimeModule } from './realtime/realtime.module';
import { HealthController } from './health/health.controller';

@Module({
  imports: [
    PrismaModule,
    EventsModule,
    AuthModule,
    WorkbooksModule,
    SheetsModule,
    RealtimeModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
```

**`apps/api/src/common/decorators/current-user.decorator.ts`**
```ts
import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export const CurrentUser = createParamDecorator(
  (_: unknown, ctx: ExecutionContext) => ctx.switchToHttp().getRequest().user,
);
```

**`apps/api/src/events/events.service.ts`**
```ts
import { Injectable } from '@nestjs/common';
import { EventEmitter } from 'events';

type Listener = (e: { workbookId: string; event: string; payload: any }) => void;

@Injectable()
export class EventsService {
  private emitter = new EventEmitter();

  emit(workbookId: string, event: string, payload: any) {
    this.emitter.emit('event', { workbookId, event, payload });
  }

  on(handler: Listener) {
    this.emitter.on('event', handler);
  }
}
```

**`apps/api/src/events/events.module.ts`**
```ts
import { Global, Module } from '@nestjs/common';
import { EventsService } from './events.service';

@Global()
@Module({
  providers: [EventsService],
  exports: [EventsService],
})
export class EventsModule {}
```

## 3. Auth

**`apps/api/src/auth/auth.guard.ts`**
```ts
import {
  CanActivate, ExecutionContext, Injectable, UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly jwt: JwtService) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const req = ctx.switchToHttp().getRequest();
    const auth = req.headers.authorization as string | undefined;
    if (!auth?.startsWith('Bearer ')) throw new UnauthorizedException();
    try {
      req.user = await this.jwt.verifyAsync(auth.slice(7));
      return true;
    } catch {
      throw new UnauthorizedException();
    }
  }
}
```

**`apps/api/src/auth/dto/login.dto.ts`**
```ts
import { IsEmail, IsString, MinLength } from 'class-validator';

export class LoginDto {
  @IsEmail() email!: string;
  @IsString() @MinLength(1) password!: string;
}
```

**`apps/api/src/auth/auth.service.ts`**
```ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async login(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user) throw new UnauthorizedException('Invalid credentials');
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) throw new UnauthorizedException('Invalid credentials');

    const token = await this.jwt.signAsync({
      sub: user.id,
      email: user.email,
      role: user.role,
    });
    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
      },
    };
  }

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException();
    return {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      role: user.role,
    };
  }
}
```

**`apps/api/src/auth/auth.controller.ts`**
```ts
import {
  Body, Controller, Get, HttpCode, Post, UseGuards,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './auth.guard';
import { LoginDto } from './dto/login.dto';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Post('login')
  @HttpCode(200)
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto.email, dto.password);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  me(@CurrentUser() user: { sub: string }) {
    return this.auth.me(user.sub);
  }
}
```

**`apps/api/src/auth/auth.module.ts`**
```ts
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';

@Module({
  imports: [
    JwtModule.register({
      global: true,
      secret: process.env.JWT_SECRET ?? 'dev-secret-change-me',
      signOptions: { expiresIn: process.env.JWT_EXPIRES_IN ?? '1d' },
    }),
  ],
  providers: [AuthService],
  controllers: [AuthController],
})
export class AuthModule {}
```

## 4. Workbooks

**`apps/api/src/workbooks/dto/create-workbook.dto.ts`**
```ts
import { IsString, Length } from 'class-validator';

export class CreateWorkbookDto {
  @IsString() @Length(1, 100) name!: string;
}
```

**`apps/api/src/workbooks/workbooks.service.ts`**
```ts
import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class WorkbooksService {
  constructor(private readonly prisma: PrismaService) {}

  async create(userId: string, name: string) {
    return this.prisma.workbook.create({
      data: {
        name,
        ownerId: userId,
        members: { create: { userId, role: 'owner' } },
      },
    });
  }

  async listForUser(userId: string) {
    return this.prisma.workbook.findMany({
      where: { members: { some: { userId } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async assertMember(workbookId: string, userId: string) {
    const m = await this.prisma.workbookMember.findUnique({
      where: { workbookId_userId: { workbookId, userId } },
    });
    if (!m) throw new ForbiddenException('No access to workbook');
    return m;
  }
}
```

**`apps/api/src/workbooks/workbooks.controller.ts`**
```ts
import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { WorkbooksService } from './workbooks.service';
import { JwtAuthGuard } from '../auth/auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { CreateWorkbookDto } from './dto/create-workbook.dto';

@Controller('workbooks')
@UseGuards(JwtAuthGuard)
export class WorkbooksController {
  constructor(private readonly workbooks: WorkbooksService) {}

  @Get()
  list(@CurrentUser() user: { sub: string }) {
    return this.workbooks.listForUser(user.sub);
  }

  @Post()
  create(@CurrentUser() user: { sub: string }, @Body() dto: CreateWorkbookDto) {
    return this.workbooks.create(user.sub, dto.name);
  }
}
```

**`apps/api/src/workbooks/workbooks.module.ts`**
```ts
import { Module } from '@nestjs/common';
import { WorkbooksService } from './workbooks.service';
import { WorkbooksController } from './workbooks.controller';

@Module({
  providers: [WorkbooksService],
  controllers: [WorkbooksController],
  exports: [WorkbooksService],
})
export class WorkbooksModule {}
```

## 5. Sheets + Cells

**`apps/api/src/sheets/dto/sheets.dto.ts`**
```ts
import {
  IsArray, IsDefined, IsInt, IsString, IsUUID, Length, Min,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

export class CreateSheetDto {
  @IsString() @Length(1, 100) name!: string;
}

export class CellChangeDto {
  @IsInt() @Min(0) row!: number;
  @IsInt() @Min(0) column!: number;
  @IsDefined() value!: unknown;
  @IsInt() @Min(0) expectedVersion!: number;
}

export class PatchCellsDto {
  @IsUUID() mutationId!: string;
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CellChangeDto)
  changes!: CellChangeDto[];
}
```

**`apps/api/src/sheets/sheets.service.ts`**
```ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { WorkbooksService } from '../workbooks/workbooks.service';

@Injectable()
export class SheetsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly workbooks: WorkbooksService,
  ) {}

  async create(workbookId: string, userId: string, name: string) {
    await this.workbooks.assertMember(workbookId, userId);
    const count = await this.prisma.sheet.count({ where: { workbookId } });
    return this.prisma.sheet.create({
      data: { workbookId, name, position: count },
    });
  }

  async list(workbookId: string, userId: string) {
    await this.workbooks.assertMember(workbookId, userId);
    return this.prisma.sheet.findMany({
      where: { workbookId },
      orderBy: { position: 'asc' },
    });
  }

  async getWithAccess(sheetId: string, userId: string) {
    const sheet = await this.prisma.sheet.findUnique({ where: { id: sheetId } });
    if (!sheet) throw new NotFoundException('Sheet not found');
    await this.workbooks.assertMember(sheet.workbookId, userId);
    return sheet;
  }
}
```

**`apps/api/src/sheets/cells.service.ts`**
```ts
import { ConflictException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { SheetsService } from './sheets.service';
import { EventsService } from '../events/events.service';
import { CellChangeDto } from './dto/sheets.dto';

@Injectable()
export class CellsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly sheets: SheetsService,
    private readonly events: EventsService,
  ) {}

  async getRows(sheetId: string, userId: string) {
    const sheet = await this.sheets.getWithAccess(sheetId, userId);
    const cells = await this.prisma.cell.findMany({ where: { sheetId } });
    const byRow = new Map<number, Record<number, { value: any; version: number }>>();
    for (const c of cells) {
      if (!byRow.has(c.row)) byRow.set(c.row, {});
      byRow.get(c.row)![c.column] = { value: c.value, version: c.version };
    }
    return {
      sheetId: sheet.id,
      rows: Array.from(byRow.entries())
        .sort(([a], [b]) => a - b)
        .map(([row, cellsByCol]) => ({ row, cells: cellsByCol })),
    };
  }

  async getEvents(sheetId: string, userId: string, after: number) {
    const sheet = await this.sheets.getWithAccess(sheetId, userId);
    return this.prisma.workbookEvent.findMany({
      where: { workbookId: sheet.workbookId, seq: { gt: after } },
      orderBy: { seq: 'asc' },
      take: 1000,
    });
  }

  async patchCells(
    sheetId: string,
    userId: string,
    mutationId: string,
    changes: CellChangeDto[],
  ) {
    const sheet = await this.sheets.getWithAccess(sheetId, userId);

    const replay = await this.prisma.cellChange.findFirst({
      where: { mutationId },
      orderBy: { createdAt: 'asc' },
    });
    if (replay) {
      const all = await this.prisma.cellChange.findMany({ where: { mutationId } });
      return {
        mutationId,
        seq: replay.seq,
        replayed: true,
        results: all.map((r) => ({
          row: r.row, column: r.column, value: r.newValue, version: r.version,
        })),
      };
    }

    const result = await this.prisma.$transaction(async (tx) => {
      const conflicts: any[] = [];
      const prepared: Array<{ ch: CellChangeDto; existing: any; currentVersion: number }> = [];

      for (const ch of changes) {
        const existing = await tx.cell.findUnique({
          where: { sheetId_row_column: { sheetId, row: ch.row, column: ch.column } },
        });
        const currentVersion = existing?.version ?? 0;
        if (currentVersion !== ch.expectedVersion) {
          conflicts.push({
            row: ch.row, column: ch.column,
            expectedVersion: ch.expectedVersion,
            currentVersion,
            currentValue: existing?.value ?? null,
          });
        } else {
          prepared.push({ ch, existing, currentVersion });
        }
      }
      if (conflicts.length) {
        throw new ConflictException({
          code: 'VERSION_CONFLICT',
          message: 'One or more cells have a newer version',
          details: { conflicts },
        });
      }

      const event = await tx.workbookEvent.create({
        data: {
          workbookId: sheet.workbookId,
          sheetId,
          type: 'cell:changed',
          payload: {
            sheetId,
            mutationId,
            changes: changes.map((c) => ({
              row: c.row, column: c.column, value: c.value,
            })),
          },
        },
      });

      const results: any[] = [];
      for (const { ch, existing, currentVersion } of prepared) {
        const newVersion = currentVersion + 1;
        const updated = await tx.cell.upsert({
          where: { sheetId_row_column: { sheetId, row: ch.row, column: ch.column } },
          create: {
            sheetId, row: ch.row, column: ch.column,
            value: ch.value as any, version: newVersion,
          },
          update: { value: ch.value as any, version: newVersion },
        });
        await tx.cellChange.create({
          data: {
            mutationId, sheetId, cellId: updated.id, userId,
            row: ch.row, column: ch.column,
            oldValue: (existing?.value as any) ?? null,
            newValue: ch.value as any,
            version: newVersion,
            seq: event.seq,
          },
        });
        results.push({
          row: ch.row, column: ch.column, value: ch.value, version: newVersion,
        });
      }
      return { mutationId, seq: event.seq, results };
    });

    this.events.emit(sheet.workbookId, 'cell:changed', {
      sheetId, seq: result.seq, changes: result.results,
    });
    return result;
  }
}
```

**`apps/api/src/sheets/sheets.controller.ts`**
```ts
import {
  Body, Controller, Get, Param, Patch, Post, Query, UseGuards,
} from '@nestjs/common';
import { SheetsService } from './sheets.service';
import { CellsService } from './cells.service';
import { JwtAuthGuard } from '../auth/auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { CreateSheetDto, PatchCellsDto } from './dto/sheets.dto';

@Controller()
@UseGuards(JwtAuthGuard)
export class SheetsController {
  constructor(
    private readonly sheets: SheetsService,
    private readonly cells: CellsService,
  ) {}

  @Get('workbooks/:id/sheets')
  list(@Param('id') workbookId: string, @CurrentUser() user: { sub: string }) {
    return this.sheets.list(workbookId, user.sub);
  }

  @Post('workbooks/:id/sheets')
  create(
    @Param('id') workbookId: string,
    @CurrentUser() user: { sub: string },
    @Body() dto: CreateSheetDto,
  ) {
    return this.sheets.create(workbookId, user.sub, dto.name);
  }

  @Get('sheets/:id/rows')
  rows(@Param('id') id: string, @CurrentUser() user: { sub: string }) {
    return this.cells.getRows(id, user.sub);
  }

  @Patch('sheets/:id/cells')
  patch(
    @Param('id') id: string,
    @CurrentUser() user: { sub: string },
    @Body() dto: PatchCellsDto,
  ) {
    return this.cells.patchCells(id, user.sub, dto.mutationId, dto.changes);
  }

  @Get('sheets/:id/events')
  events(
    @Param('id') id: string,
    @CurrentUser() user: { sub: string },
    @Query('after') after?: string,
  ) {
    return this.cells.getEvents(id, user.sub, Number(after ?? 0));
  }
}
```

**`apps/api/src/sheets/sheets.module.ts`**
```ts
import { Module } from '@nestjs/common';
import { SheetsService } from './sheets.service';
import { CellsService } from './cells.service';
import { SheetsController } from './sheets.controller';
import { WorkbooksModule } from '../workbooks/workbooks.module';

@Module({
  imports: [WorkbooksModule],
  providers: [SheetsService, CellsService],
  controllers: [SheetsController],
  exports: [SheetsService, CellsService],
})
export class SheetsModule {}
```

## 6. Realtime

**`apps/api/src/realtime/realtime.gateway.ts`**
```ts
import { OnModuleInit } from '@nestjs/common';
import {
  ConnectedSocket, MessageBody, SubscribeMessage,
  WebSocketGateway, WebSocketServer,
} from '@nestjs/websockets';
import { JwtService } from '@nestjs/jwt';
import { Server, Socket } from 'socket.io';
import { WorkbooksService } from '../workbooks/workbooks.service';
import { CellsService } from '../sheets/cells.service';
import { EventsService } from '../events/events.service';

@WebSocketGateway({
  namespace: '/ws',
  cors: { origin: true, credentials: true },
})
export class RealtimeGateway implements OnModuleInit {
  @WebSocketServer() server!: Server;

  constructor(
    private readonly jwt: JwtService,
    private readonly workbooks: WorkbooksService,
    private readonly cells: CellsService,
    private readonly events: EventsService,
  ) {}

  onModuleInit() {
    this.events.on(({ workbookId, event, payload }) => {
      this.server.to(`wb:${workbookId}`).emit(event, payload);
    });
  }

  async handleConnection(client: Socket) {
    const token = (client.handshake.auth?.token ?? '') as string;
    try {
      const payload = await this.jwt.verifyAsync(token);
      (client.data as any).user = payload;
    } catch {
      client.disconnect();
    }
  }

  @SubscribeMessage('workbook:join')
  async join(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { workbookId: string },
  ) {
    const user = (client.data as any).user;
    if (!user) return { ok: false, error: 'unauthenticated' };
    try {
      await this.workbooks.assertMember(body.workbookId, user.sub);
      client.join(`wb:${body.workbookId}`);
      return { ok: true };
    } catch {
      return { ok: false, error: 'forbidden' };
    }
  }

  @SubscribeMessage('cell:mutate')
  async mutate(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: {
      workbookId: string;
      sheetId: string;
      mutationId: string;
      changes: any[];
    },
  ) {
    const user = (client.data as any).user;
    if (!user) return { ok: false, error: 'unauthenticated' };
    try {
      const result = await this.cells.patchCells(
        body.sheetId, user.sub, body.mutationId, body.changes,
      );
      return { ok: true, ...result };
    } catch (e: any) {
      const resp = e?.getResponse?.() ?? {};
      client.emit('cell:conflict', {
        sheetId: body.sheetId,
        mutationId: body.mutationId,
        conflicts: resp?.details?.conflicts ?? [],
      });
      return { ok: false, error: resp?.code ?? 'ERROR' };
    }
  }
}
```

**`apps/api/src/realtime/realtime.module.ts`**
```ts
import { Module } from '@nestjs/common';
import { RealtimeGateway } from './realtime.gateway';
import { WorkbooksModule } from '../workbooks/workbooks.module';
import { SheetsModule } from '../sheets/sheets.module';

@Module({
  imports: [WorkbooksModule, SheetsModule],
  providers: [RealtimeGateway],
})
export class RealtimeModule {}
```

## 7. Запуск

```powershell
# из корня проекта
pnpm install

# новая миграция (drop @unique на mutationId, add seq, add sheetId в workbook_events)
pnpm --filter @asgrid/api exec prisma migrate dev --name auth_books_cells_realtime

# создать админа
pnpm --filter @asgrid/api exec prisma db seed

# запуск
pnpm dev
```

Если Prisma не видит `.env` — напомню, что файл должен быть в `apps/api/.env` (вы копировали ранее — при изменении корневого `.env` обновите копию).

## 8. Проверка (curl / Invoke-RestMethod)

```powershell
# 1. Login
$login = Invoke-RestMethod -Method Post `
  -Uri http://localhost:3001/api/v1/auth/login `
  -ContentType 'application/json' `
  -Body '{"email":"admin@asgrid.local","password":"admin123"}'
$token = $login.token
$h = @{ Authorization = "Bearer $token" }

# 2. Me
Invoke-RestMethod -Uri http://localhost:3001/api/v1/auth/me -Headers $h

# 3. Создать книгу
$wb = Invoke-RestMethod -Method Post -Uri http://localhost:3001/api/v1/workbooks `
  -Headers $h -ContentType 'application/json' -Body '{"name":"Тест"}'

# 4. Создать лист
$sh = Invoke-RestMethod -Method Post `
  -Uri "http://localhost:3001/api/v1/workbooks/$($wb.id)/sheets" `
  -Headers $h -ContentType 'application/json' -Body '{"name":"Лист1"}'

# 5. Записать ячейку (expectedVersion 0 = новая ячейка)
$mid = [guid]::NewGuid().ToString()
$body = @{
  mutationId = $mid
  changes = @(@{ row = 0; column = 0; value = 250; expectedVersion = 0 })
} | ConvertTo-Json -Depth 5

$r = Invoke-RestMethod -Method Patch `
  -Uri "http://localhost:3001/api/v1/sheets/$($sh.id)/cells" `
  -Headers $h -ContentType 'application/json' -Body $body
$r

# 6. Повторить тот же mutationId — должен вернуть replayed: true и тот же version
Invoke-RestMethod -Method Patch `
  -Uri "http://localhost:3001/api/v1/sheets/$($sh.id)/cells" `
  -Headers $h -ContentType 'application/json' -Body $body

# 7. Отправить с устаревшей версией — ожидается 409 с conflicts
$body2 = @{
  mutationId = [guid]::NewGuid().ToString()
  changes = @(@{ row = 0; column = 0; value = 999; expectedVersion = 0 })
} | ConvertTo-Json -Depth 5
try {
  Invoke-RestMethod -Method Patch `
    -Uri "http://localhost:3001/api/v1/sheets/$($sh.id)/cells" `
    -Headers $h -ContentType 'application/json' -Body $body2
} catch {
  $_.ErrorDetails.Message
}
```

Ожидаемые результаты:
- Шаг 5: `{ mutationId, seq, results: [{ row:0, column:0, value:250, version:1 }] }`.
- Шаг 6: тот же ответ + `replayed: true`.
- Шаг 7: 409 с `details.conflicts[0].currentVersion = 1`, `currentValue = 250`.

## Что готово и что дальше

Готово (Milestone 1, backend):
- ✅ JWT-логин, `GET /auth/me`, seed админа.
- ✅ Книги, листы, проверка членства на каждом эндпоинте.
- ✅ Сохранение ячеек с версиями, идемпотентностью по `mutationId`, событием в `workbook_events`.
- ✅ `GET /rows`, `GET /events?after=`.
- ✅ WebSocket `/ws`: `workbook:join`, `cell:mutate`, исходящие `cell:changed` / `cell:conflict`.

Дальше — **Milestone 1.5 (клиент)**: реальное подключение React к API, AG Grid с сохранением, WebSocket-клиент, восстановление после обрыва. Могу выдать его следующим сообщением целиком (экраны: login → список книг → редактор листа), либо сначала только auth и загрузку строк, чтобы вы проверили связку вручную. Как удобнее?