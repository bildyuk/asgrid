Отлично! Базовый цикл заработал: авторизация, создание книг, сохранение ячеек и real-time синхронизация.

Но сейчас в коде `SheetGrid.tsx` осталась одна заглушка, которую я отмечал:
```tsx
socket.emit('workbook:join', { workbookId: 'test' });
```
Из-за неё WebSocket-события будут приходить всем пользователям **сразу во все книги**, а не только в ту, которую они открыли. Давайте исправим это, передав реальный `workbookId` из списка книг в грид.

### 1. Обновляем `WorkbookList.tsx`

Нужно передавать `workbookId` вместе с `sheetId`:

```tsx
// apps/web/src/components/WorkbookList.tsx
// (изменения в интерфейсе пропсов и в вызове onSelectSheet)

type Props = {
  onSelectSheet: (sheetId: string, workbookId: string, name: string) => void;
};

export function WorkbookList({ onSelectSheet }: Props) {
  // ... (остальной код без изменений)

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      {/* ... */}
            {sheets[wb.id] && (
              <ul style={{ paddingLeft: 20 }}>
                {sheets[wb.id].map((sh) => (
                  <li 
                    key={sh.id} 
                    style={{ cursor: 'pointer', color: 'blue' }} 
                    onClick={() => onSelectSheet(sh.id, wb.id, `${wb.name} / ${sh.name}`)}
                  >
                    📄 {sh.name}
                  </li>
                ))}
                {/* ... */}
              </ul>
            )}
      {/* ... */}
    </div>
  );
}
```

### 2. Обновляем `App.tsx`

Сохраняем `workbookId` в стейте выбранного листа:

```tsx
// apps/web/src/App.tsx
import { useState } from 'react';
import { getToken } from './api/client';
import { Login } from './components/Login';
import { WorkbookList } from './components/WorkbookList';
import { SheetGrid } from './components/SheetGrid';
import './App.css';

type SelectedSheet = { id: string; workbookId: string; name: string };

export default function App() {
  const [isAuth, setIsAuth] = useState(!!getToken());
  const [selectedSheet, setSelectedSheet] = useState<SelectedSheet | null>(null);

  if (!isAuth) {
    return <Login onLogin={() => setIsAuth(true)} />;
  }

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif' }}>
      <header style={{ background: '#0070c0', color: '#fff', padding: '10px 20px', display: 'flex', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>ASGRID</h2>
        <button onClick={() => { localStorage.clear(); window.location.reload(); }}>Выйти</button>
      </header>
      {selectedSheet ? (
        <SheetGrid
          sheetId={selectedSheet.id}
          workbookId={selectedSheet.workbookId}
          title={selectedSheet.name}
          onBack={() => setSelectedSheet(null)}
        />
      ) : (
        <WorkbookList
          onSelectSheet={(id, wbId, name) => setSelectedSheet({ id, workbookId: wbId, name })}
        />
      )}
    </div>
  );
}
```

### 3. Обновляем `SheetGrid.tsx`

Принимаем `workbookId` и используем его при подключении к комнате:

```tsx
// apps/web/src/components/SheetGrid.tsx
// (меняем сигнатуру пропсов и вызов join)

export function SheetGrid({ sheetId, workbookId, title, onBack }: { 
  sheetId: string; 
  workbookId: string; 
  title: string; 
  onBack: () => void 
}) {
  // ... (остальной код без изменений до useEffect)

  useEffect(() => {
    loadRows();

    socket.connect();
    // Передаем реальный ID книги!
    socket.emit('workbook:join', { workbookId }); 

    const handleCellChanged = (payload: any) => {
      // ... (обработчик без изменений)
    };

    socket.on('cell:changed', handleCellChanged);
    return () => { socket.off('cell:changed', handleCellChanged); };
  }, [sheetId, workbookId, loadRows, socket]); // Добавили workbookId в зависимости

  // ... (остальной код)
}
```

---

### Проверка изоляции книг

Теперь можно проверить, что события не «протекают» между разными книгами:

1. Создайте **две** книги (`Книга 1` и `Книга 2`), в каждой по листу.
2. Откройте `Книга 1` в обычном окне, а `Книга 2` — в инкогнито.
3. Введите значение в `Книга 1`. Оно **не должно** появиться в `Книга 2`.

Если это работает — мы закрыли Milestone 1.5.

### Что дальше (Milestone 2)

Осталась одна важная вещь из ТЗ — **восстановление пропущенных событий**. Если у пользователя на секунду пропал интернет (или он свернул ноутбук), WebSocket отключится. При переподключении клиент должен спросить сервер: «А что я пропустил?» через `GET /sheets/:id/events?after=<seq>`.

Сейчас клиент этого не делает. Если готовы, я покажу, как добавить отслеживание `seq` и догон событий при реконнекте (это примерно 20 строк кода в `SheetGrid.tsx`). Делаем?